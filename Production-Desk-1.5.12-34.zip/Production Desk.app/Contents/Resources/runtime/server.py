#!/usr/bin/env python3
"""Production Desk: a loopback-only, dependency-free film scheduling server."""
from app_preferences import validate_preferences
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import threading
import time
import uuid
import struct
import sys
import io
import base64
import re
from functools import lru_cache
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit
from film import empty_project, import_script, prepare_project, element
from lined import MAX_BACKUP, store_pdf, pdf_path, add_backup_pdfs, restore_backup_pdfs

from project_file import export_project, import_project, validate_workspace

ROOT = Path(__file__).resolve().parent
LOCK = threading.Lock()
EXPORTS = {}
MAX_BODY = 40 * 1024 * 1024


def json_object(raw):
    def distinct_keys(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('This file contains duplicate JSON fields: ' + key[:80])
            result[key] = value
        return result
    try:
        value = json.loads(raw, object_pairs_hook=distinct_keys, parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Invalid JSON number.')))
    except (json.JSONDecodeError, RecursionError):
        raise ValueError('This file is corrupt or is not valid supported JSON.') from None
    if not isinstance(value, dict):
        raise ValueError('Expected a JSON object.')
    return value

@lru_cache(maxsize=5)
def local_font(family='heading', style='regular'):
    """Find installed fonts without bundling or downloading another app's assets."""
    names = {'Reross-Quadratic', 'RerossStd-Quadratic'}
    roots = [Path.home() / 'Library/Fonts', Path('/Library/Fonts')]
    if sys.platform == 'win32':
        roots = [Path(os.environ.get('WINDIR', 'C:/Windows')) / 'Fonts',
                 Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'Microsoft/Windows/Fonts']
        if family == 'script':
            for variable in ('ProgramFiles', 'ProgramFiles(x86)'):
                base = Path(os.environ.get(variable, 'C:/Program Files'))
                for application in base.glob('Final Draft*'):
                    roots.extend([application, application / 'Fonts', application / 'Resources/Fonts'])
    adobe = Path.home() / 'Library/Application Support/Adobe/CoreSync/plugins/livetype'
    roots.extend(adobe / part for part in ('.r', '.w'))
    if family == 'script':
        names = {'regular': {'CourierFinalDraft'}, 'bold': {'CourierFinalDraft-Bold'},
                 'italic': {'CourierFinalDraft-Italic'}, 'bold-italic': {'CourierFinalDraft-BoldItalic'}}.get(style, set())
        for applications in (Path('/Applications'), Path.home() / 'Applications'):
            roots.extend(app / 'Contents/Resources' for app in applications.glob('Final Draft*.app'))
    for root in roots:
        for path in root.glob('*'):
            if path.suffix.lower() not in ('.otf', '.ttf'):
                continue
            try:
                raw = path.read_bytes()
                tables = struct.unpack_from('>H', raw, 4)[0]
                for n in range(tables):
                    tag, _, offset, length = struct.unpack_from('>4sIII', raw, 12 + n * 16)
                    if tag != b'name':
                        continue
                    _, count, strings = struct.unpack_from('>HHH', raw, offset)
                    for i in range(count):
                        platform, _, _, name_id, size, start = struct.unpack_from('>HHHHHH', raw, offset + 6 + 12 * i)
                        if name_id != 6:
                            continue
                        value = raw[offset + strings + start:offset + strings + start + size]
                        name = value.decode('utf-16-be' if platform in (0, 3) else 'mac_roman')
                        if name in names:
                            return path
            except (OSError, ValueError, struct.error):
                continue
    return None

def heading_font():
    return local_font()

DEMO = """Title: The Last Light

1 EXT. COASTAL ROAD - DAWN

A battered station wagon follows the coast. The lighthouse is a pin of light in the mist.

MAYA
We should have left yesterday.

ELI
And missed all this?

2 INT. STATION WAGON - DAY

Maya unfolds an old map. A red circle marks the lighthouse.

MAYA
That's where he said he'd be.

ELI
Then that's where we go.

3 EXT. LIGHTHOUSE - DAY

The car rolls to a stop. JONAH waits at the foot of the lighthouse, holding a brass key.

JONAH
I wasn't sure you'd come.

MAYA
Neither was I.

4 INT. LIGHTHOUSE STAIRWELL - DAY

Jonah leads Maya up a winding staircase. She runs a hand along the worn stone.

JONAH
One hundred and twelve steps. Your father counted every morning.

MAYA
Of course he did.

5 INT. LANTERN ROOM - DAY

Eli opens a wooden box. Inside: a letter, a photograph, and a compass.

ELI
This has your name on it.

MAYA
Let me see.

6 EXT. LIGHTHOUSE - DUSK

Maya and Jonah sit on the seawall. The tide comes in below them.

MAYA
How long do you think he waited?

JONAH
As long as he needed to.

7 INT. LANTERN ROOM - NIGHT

Maya turns the brass key. The old mechanism wakes with a low, steady hum.

MAYA
There you are.

8 EXT. COASTAL ROAD - NIGHT

Eli closes the car door. They look back. The lighthouse sweeps across the water.

ELI
Ready?

MAYA
Now I am.
"""

def demo_workspace():
    p = import_script(DEMO, "The Last Light.fountain")
    p["_demo"] = True
    p["_importNotes"] = None
    descriptions = ["Maya and Eli drive toward the lighthouse.", "An old map points to their destination.",
                    "Jonah greets Maya with her father's key.", "Maya retraces her father's morning ritual.",
                    "Eli discovers a letter addressed to Maya.", "Maya and Jonah talk as the tide comes in.",
                    "Maya brings the lighthouse back to life.", "Maya and Eli leave the coast behind."]
    for i, b in enumerate(p["breakdowns"]):
        b["description"] = descriptions[i]
        b["pages"] = [.375, .75, 1.125, .5, 1.25, .875, .625, .375][i]
        b["duration"] = [60, 75, 90, 45, 90, 60, 75, 45][i] * 60000
        b["_needsReview"] = False
        b["elements"].append(element(p, 6, "North coast" if i in (0, 1, 7) else "Point Harbor lighthouse"))
    for i, name in [(1, "Folded road map"), (2, "Brass key"), (4, "Letter"), (4, "Compass"), (6, "Brass key")]:
        p["breakdowns"][i]["elements"].append(element(p, 104, name))
    for i in (0, 1, 7):
        p["breakdowns"][i]["elements"].append(element(p, 103, "Station wagon"))
    ids = [b["id"] for b in p["breakdowns"]]
    p["stripboards"][0]["boards"][0]["breakdownIds"] = [[ids[2], ids[3], ids[4]], [ids[5], ids[6]]]
    p["stripboards"][0]["boards"][1]["breakdownIds"] = [ids[0], ids[1], ids[7]]
    return {"version": 1, "activeProject": p["id"], "projects": [p]}

def atomic_save(path, value):
    raw = json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2)
    path.parent.mkdir(parents=True, exist_ok=True)
    # Keep the previous successfully saved version for recovery.
    if path.exists():
        shutil.copy2(path, path.with_suffix(".previous.json"))
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".slate-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(raw)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)

def extract_pdf(raw):
    if sys.platform != 'darwin':
        try:
            from pypdf import PdfReader
            reader = PdfReader(io.BytesIO(raw))
            if reader.is_encrypted and not reader.decrypt(''):
                raise ValueError('This PDF is password-protected. Export an unencrypted PDF first.')
            text = '\n\f\n'.join(page.extract_text() or '' for page in reader.pages)
        except ImportError as error:
            raise ValueError('The PDF reader is missing. Reinstall Production Desk.') from error
        except Exception as error:
            raise ValueError('Could not read this PDF: ' + str(error)) from error
        if not text.strip():
            raise ValueError('This PDF has no extractable text. Export a searchable PDF or use Final Draft (.fdx).')
        return text
    executable = ROOT / "tools" / "extract_pdf"
    if not executable.exists():
        compiler = shutil.which("swiftc")
        if not compiler:
            raise ValueError("PDF import on this computer requires macOS PDFKit and Swift. Final Draft and text import are available.")
        env = dict(os.environ, CLANG_MODULE_CACHE_PATH=str(ROOT / ".cache" / "clang"))
        result = subprocess.run([compiler, "-module-cache-path", str(ROOT / ".cache" / "swift"),
                                 str(ROOT / "tools" / "extract_pdf.swift"), "-o", str(executable)],
                                capture_output=True, env=env, timeout=120)
        if result.returncode:
            raise ValueError("The local PDF reader could not be built. Use an FDX file or a text export. See the terminal for setup details.")
    with tempfile.NamedTemporaryFile(suffix=".pdf") as f:
        f.write(raw)
        f.flush()
        result = subprocess.run([str(executable), f.name], capture_output=True, timeout=60)
    if result.returncode:
        raise ValueError(result.stderr.decode("utf-8", "replace").strip())
    return result.stdout.decode("utf-8")

class Handler(SimpleHTTPRequestHandler):
    # Windows registry MIME overrides can label ES modules as plain text.
    # Chromium rejects those responses with nosniff enabled.
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map,
                      '.js': 'text/javascript', '.mjs': 'text/javascript',
                      '.wasm': 'application/wasm'}
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT / "web"), **kwargs)

    def log_request(self, code='-', size='-'):
        # Keep query parameters out of the desktop log.
        self.log_message('"%s %s" %s %s', self.command, urlsplit(self.path).path, code, size)

    def preferences(self):
        path = self.server.datafile.parent / 'app-settings.json'
        try:
            value = json.loads(path.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            value = {}
        theme = value.get('theme') if isinstance(value, dict) else None
        output = {'theme': theme if theme in ('light', 'dark') else 'light'}
        for key in ('linedKeyBinds', 'linedLabelOpacity'):
            if isinstance(value, dict) and key in value:
                try:
                    output.update(validate_preferences({key: value[key]}))
                except ValueError:
                    pass
        return output

    def support_report(self, value=None):
        path = self.server.datafile.parent / 'support-crash.json'
        if value is None:
            try:
                value = json.loads(path.read_text(encoding='utf-8'))
            except (OSError, ValueError):
                return None
        if not isinstance(value, dict) or value.get('kind') not in ('script', 'promise', 'renderer', 'backend', 'session', 'startup'):
            raise ValueError('Invalid crash report type.')
        report = {}
        for key, limit in [('kind', 20), ('time', 50), ('message', 500), ('location', 150), ('version', 50)]:
            field = value.get(key, '')
            if not isinstance(field, str) or len(field) > limit:
                raise ValueError('Invalid crash report details.')
            report[key] = field
        return report

    def end_headers(self):
        self.send_header("Content-Security-Policy", "default-src 'self'; connect-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; worker-src 'self'; font-src 'self' data: blob:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def local_request(self, mutation=False):
        allowed = {"127.0.0.1:" + str(self.server.server_port), "localhost:" + str(self.server.server_port)}
        if self.headers.get("Host") not in allowed:
            self.reply({"error": "Only localhost requests are allowed."}, 403)
            return False
        origin = self.headers.get("Origin")
        if origin and origin not in {"http://" + host for host in allowed}:
            self.reply({"error": "Cross-origin requests are blocked."}, 403)
            return False
        if mutation and self.headers.get("X-Slate-Local") != "1":
            self.reply({"error": "Local app request header is required."}, 403)
            return False
        return True

    def reply(self, value, status=200):
        raw = json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def export_file(self, filename, mime, raw):
        if not isinstance(filename, str) or not re.fullmatch(r'[\w .-]{1,200}', filename, re.ASCII):
            raise ValueError('Invalid export filename.')
        token = uuid.uuid4().hex
        with LOCK:
            for key in list(EXPORTS):
                if time.monotonic() - EXPORTS[key][3] > 300:
                    del EXPORTS[key]
            EXPORTS[token] = (filename, mime, raw, time.monotonic())
        return {'url': '/api/download/' + token}

    def do_GET(self):
        if not self.local_request():
            return
        path = urlsplit(self.path).path
        font_routes = {'/fonts/heading.otf': ('heading', 'regular'),
                       '/fonts/script-regular.ttf': ('script', 'regular'),
                       '/fonts/script-bold.ttf': ('script', 'bold'),
                       '/fonts/script-italic.ttf': ('script', 'italic'),
                       '/fonts/script-bold-italic.ttf': ('script', 'bold-italic')}
        if path in font_routes:
            font = local_font(*font_routes[path])
            if not font:
                self.reply({"error": "The requested local font is unavailable."}, 404)
                return
            try:
                raw = font.read_bytes()
            except OSError:
                self.reply({"error": "Local font could not be read."}, 404)
                return
            self.send_response(200)
            self.send_header("Content-Type", "font/ttf" if path.endswith('.ttf') else "font/otf")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
        elif path.startswith('/api/pdf/'):
            try:
                source = pdf_path(self.server.datafile, path.rsplit('/', 1)[-1])
                raw = source.read_bytes()
            except (ValueError, OSError):
                self.reply({'error': 'Original PDF unavailable. Reattach the original file.'}, 404)
                return
            self.send_response(200)
            self.send_header('Content-Type', 'application/pdf')
            self.send_header('Content-Length', str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
        elif path.startswith("/api/download/"):
            token = path.rsplit("/", 1)[-1]
            with LOCK:
                item = EXPORTS.get(token)
            if not item or time.monotonic() - item[3] > 300:
                self.reply({"error": "Export expired. Export the file again."}, 404)
                return
            filename, mime, raw, _ = item
            self.send_response(200)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Disposition", 'attachment; filename="' + filename + '"')
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
        elif path == '/api/support':
            try:
                with LOCK:
                    report = self.support_report()
                self.reply({'report': report})
            except ValueError:
                self.reply({'report': None})
        elif path == '/api/settings':
            with LOCK:
                self.reply({'preferences': self.preferences()})
        elif path == "/api/workspace":
            try:
                with LOCK:
                    if not self.server.datafile.exists():
                        atomic_save(self.server.datafile, demo_workspace())
                    value = json_object(self.server.datafile.read_text(encoding="utf-8"))
                    if not isinstance(value.get('projects'), list) or not value['projects']:
                        raise ValueError('The workspace must contain a production.')
                    for project in value['projects']:
                        prepare_project(project)
                self.reply(value)
            except (OSError, ValueError, KeyError, TypeError) as e:
                self.reply({"error": "Could not read local workspace: " + str(e)}, 500)
        elif path.startswith("/api/"):
            self.reply({"error": "Not found"}, 404)
        else:
            super().do_GET()

    def do_POST(self):
        if not self.local_request(mutation=True):
            return
        try:
            path = urlsplit(self.path).path
            length = int(self.headers.get("Content-Length", "0"))
            backup_import = path == '/api/import' and self.headers.get('X-Filename', '').lower().endswith(('.json', '.uss', '.productiondesk'))
            limit = MAX_BACKUP if backup_import or path == '/api/export' else MAX_BODY
            if path in ('/api/support', '/api/support/export'):
                limit = 16384
            if length <= 0 or length > limit:
                self.reply({"error": "Support reports must be smaller than 16 KB." if limit == 16384 else "Request exceeds the " + str(limit // 1024 // 1024) + " MB limit."}, 413)
                return
            raw = self.rfile.read(length)
            if path == '/api/support':
                value = json_object(raw)
                if value.get('action') == 'clear':
                    with LOCK:
                        path = self.server.datafile.parent / 'support-crash.json'
                        path.unlink(missing_ok=True)
                        path.with_name('support-crash.previous.json').unlink(missing_ok=True)
                    self.reply({'report': None})
                    return
                if value.get('action') != 'record':
                    raise ValueError('Choose a report action.')
                if not isinstance(value.get('report'), dict):
                    raise ValueError('Crash details are required.')
                report = self.support_report(value['report'])
                if report is None:
                    raise ValueError('Crash details are required.')
                with LOCK:
                    atomic_save(self.server.datafile.parent / 'support-crash.json', report)
                self.reply({'report': report})
            elif path == '/api/support/export':
                value = json_object(raw)
                content = value.get('content')
                if not isinstance(content, str) or not content or len(content) > 10000:
                    raise ValueError('Invalid support report.')
                self.reply(self.export_file('Production-Desk-support-report.txt', 'text/plain;charset=utf-8', content.encode('utf-8')))
            elif path == '/api/pdf':
                from urllib.parse import unquote
                document = store_pdf(self.server.datafile, raw, unquote(self.headers.get('X-Filename', 'script.pdf')))
                self.reply({'document': document})
            elif path == '/api/project-file':
                value = json_object(raw)
                contents = export_project(self.server.datafile, value.get('workspace'))
                self.reply(self.export_file(value.get('filename'), 'application/vnd.productiondesk.project+json', contents))
            elif path == '/api/backup':
                value = json_object(raw)
                workspace = value.get('workspace')
                if not isinstance(workspace, dict) or not isinstance(workspace.get('projects'), list):
                    raise ValueError('Invalid backup workspace.')
                for project in workspace['projects']:
                    prepare_project(project)
                backup = add_backup_pdfs(self.server.datafile, workspace)
                contents = json.dumps(backup, ensure_ascii=False, allow_nan=False, indent=2).encode('utf-8')
                if len(contents) > MAX_BACKUP:
                    raise ValueError('This backup exceeds 200 MB.')
                self.reply(self.export_file(value.get('filename'), 'application/json', contents))
            elif path == '/api/settings':
                value = json_object(raw)
                changes = validate_preferences(value)
                if not changes:
                    raise ValueError('Choose app settings to save.')
                with LOCK:
                    preferences = dict(self.preferences(), **changes)
                    atomic_save(self.server.datafile.parent / 'app-settings.json', preferences)
                self.reply({'preferences': preferences})
            elif path == "/api/export":
                value = json_object(raw)
                filename = value.get("filename", "")
                content = value.get("content")
                mime = value.get("mime")
                import re
                if not isinstance(filename, str) or not re.fullmatch(r"[\w .-]{1,200}", filename, re.ASCII):
                    raise ValueError("Invalid export filename.")
                if not isinstance(content, str) or mime not in ("application/json", "text/csv;charset=utf-8", 'application/pdf'):
                    raise ValueError("Invalid export contents.")
                if mime == 'application/pdf':
                    if value.get('encoding') != 'base64':
                        raise ValueError('Invalid PDF export encoding.')
                    contents = base64.b64decode(content, validate=True)
                    if not contents.startswith(b'%PDF-'):
                        raise ValueError('Invalid PDF export.')
                else:
                    contents = content.encode('utf-8')
                self.reply(self.export_file(filename, mime, contents))
            elif path == "/api/workspace":
                value = json_object(raw)
                validate_workspace(value)
                with LOCK:
                    atomic_save(self.server.datafile, value)
                self.reply({"saved": True})
            elif path == "/api/new":
                self.reply(empty_project(json_object(raw).get("title") or "Untitled production"))
            elif path == "/api/import":
                filename = self.headers.get("X-Filename", "script.txt")
                from urllib.parse import unquote
                filename = Path(unquote(filename)).name
                if filename.lower().endswith((".uss", ".json", ".productiondesk")):
                    value = json_object(raw)
                    if filename.lower().endswith('.productiondesk') or 'format' in value:
                        self.reply({'workspace': import_project(self.server.datafile, value)})
                    elif "universalScheduleStandard" in value:
                        p = prepare_project(value["universalScheduleStandard"])
                        self.reply({"project": p})
                    elif value.get("version") == 1 and isinstance(value.get("projects"), list):
                        validate_workspace(value)
                        restore_backup_pdfs(self.server.datafile, value)
                        self.reply({"workspace": value})
                    else:
                        raise ValueError("Select a USS file or a Production Desk workspace backup.")
                else:
                    text = extract_pdf(raw) if filename.lower().endswith(".pdf") else raw.decode("utf-8-sig")
                    project = import_script(text, filename)
                    if not filename.lower().endswith('.pdf'):
                        project['_sourceScript'] = {'filename': filename, 'text': text}
                    if filename.lower().endswith('.pdf'):
                        document = store_pdf(self.server.datafile, raw, filename)
                        project['_linedScript'] = {'activePdf': document['sha256'], 'documents': [document]}
                    self.reply({"project": project})
            else:
                self.reply({"error": "Not found"}, 404)
        except (ValueError, KeyError, TypeError, UnicodeError, RecursionError, subprocess.TimeoutExpired) as e:
            self.reply({"error": str(e) or "Could not read that file."}, 400)
        except OSError as e:
            self.reply({"error": "Local file operation failed: " + str(e)}, 500)

def main():
    if sys.stdout and hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    if sys.stderr and hasattr(sys.stderr, 'reconfigure'):
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    parser = argparse.ArgumentParser(description="Production Desk — offline film scheduling")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--data", type=Path, default=ROOT / "data" / "workspace.json")
    parser.add_argument("--ready-file", type=Path, help="Write the local URL for the desktop launcher")
    parser.add_argument("--parent-pid", type=int, help="Stop when the desktop launcher exits")
    args = parser.parse_args()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    server.datafile = args.data.resolve()
    if args.ready_file:
        args.ready_file.parent.mkdir(parents=True, exist_ok=True)
        args.ready_file.write_text(json.dumps({"url": "http://127.0.0.1:%s" % server.server_port}), encoding="utf-8")
    if args.parent_pid:
        def watch_parent():
            if sys.platform == 'win32':
                # Windows keeps the original parent PID after it exits; wait on its handle.
                import ctypes
                kernel = ctypes.WinDLL('kernel32', use_last_error=True)
                kernel.OpenProcess.restype = ctypes.c_void_p
                kernel.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
                kernel.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
                kernel.CloseHandle.argtypes = [ctypes.c_void_p]
                handle = kernel.OpenProcess(0x00100000, False, args.parent_pid)
                if handle:
                    kernel.WaitForSingleObject(handle, 0xFFFFFFFF)
                    kernel.CloseHandle(handle)
            else:
                while os.getppid() == args.parent_pid:
                    time.sleep(1)
            server.shutdown()
        threading.Thread(target=watch_parent, daemon=True).start()
    print("\nProduction Desk is running at http://127.0.0.1:%s" % server.server_port, flush=True)
    print("Data: " + str(server.datafile) + "\nPress Control-C to stop.\n", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.server_close()

if __name__ == "__main__":
    main()
