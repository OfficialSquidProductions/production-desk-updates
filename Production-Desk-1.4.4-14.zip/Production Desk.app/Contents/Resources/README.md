# Production Desk — local film scheduling

Production Desk is a self-hosted scheduling app for one computer. It uses the script / breakdown / stripboard workflow: read a screenplay, tag production elements, edit a scene sheet, and arrange strips into shooting days. Its interface is inspired by pane-based film scheduling workflows; it is an independent app.

## Start on this Mac

For a native, offline iPad version installed free through Xcode, open **ipad/Scheduler.xcodeproj** and follow [the iPad setup guide](ipad/README.md). The iPad stores its own projects; full workspace backups transfer productions between devices.

The packaged desktop version is **~/Applications/Production Desk.app**. Open it from Finder or Spotlight; it starts its own local server and opens Production Desk in a native window. No Terminal or separately installed Python is needed. Drag the app to the Dock for a one-click launch. Closing its window or choosing **Production Desk → Quit Production Desk** saves pending changes and stops its server.

Version **1.4.3** includes a Sparkle updater. Choose **Production Desk → Check for Updates…**; the **Updates** submenu controls daily automatic checks and optional automatic downloading/installation. Automatic checks default on; automatic downloading/installation defaults off. Downloads are signature-verified before extraction. Installing an update waits for project changes to save; if saving fails, keep working and use **Continue Installing Update…** to retry. Existing 1.3.x users need one manual installation of the current share package. The configured update feed is **https://updates.squidproductions.org/appcast.xml**. The HTTPS feed and signed downloads are live on GitHub Pages, connected through Squarespace DNS. See [update release and domain setup](desktop/UPDATES.md).

To install, open **dist/Production-Desk-macOS.dmg** and drag **Production Desk.app** onto **Applications**. The current desktop build supports Apple Silicon Macs on macOS 12 or newer. It is signed locally for personal use, without Apple developer notarization. The Windows version uses the same interface and scheduling features, packaged as one offline `.exe` installer. See [the Windows guide](desktop/windows/README.md).

The public download page is **https://productiondesk.squidproductions.org/**. Its Mac button reads the live update feed; its Windows button downloads the latest verified `.exe` installer from GitHub Releases. For sharing the installer, send **dist/Production-Desk-Share-Mac.zip**. Recipients unzip it and open **Install Production Desk.app** inside **Production Desk — Share**. The installer automatically copies the complete app into their own **~/Applications** folder and launches it. It needs no admin password, Terminal, additional downloads, or internet. Quit an existing Production Desk instance before updating. The folder includes a short setup guide. This package supports Apple Silicon Macs; it does not support Intel Macs or Windows. macOS may require approval the first time a downloaded copy is opened because this personal build is not Apple-notarized.

The renamed app retains its legacy data folder and app identifier so existing projects and window settings continue to work. Desktop projects are stored in **~/Library/Application Support/Slate/workspace.json**, with a previous-save backup alongside them. New users start with a fictional sample. Project data and private font files are never bundled into the app, installer, ZIP, or DMG. Replacing the app with a later version preserves that data folder. Use **Production Desk → Open Data Folder** to find it. Desktop imports and exports use native file dialogs; printing includes Save as PDF.

The following Terminal-based method remains available for development:

Double-click **Start Production Desk.command**, then open **http://127.0.0.1:8765** in Safari, Chrome, or another modern browser. Keep the terminal window open while working. Press Control-C to stop the server. If macOS blocks the command file, run `python3 server.py` from this folder in Terminal.

Python 3.9 or later is required and is already available on this computer. No pip or npm installation is required. PDF import uses macOS PDFKit; a compiled helper is included on this computer. When copying the source to another Mac, it is built locally with Swift on first PDF import. Final Draft, Fountain, TXT, and USS imports do not need the PDF helper.

The initial production is **The Last Light**, a fictional sample. Choose **New production** for a blank project or **Import script / USS** to import your own script. Every import creates a separate production, preserving existing projects. Select productions with the sidebar dropdown.

## Workflow

1. Import a PDF with selectable text, a Final Draft `.fdx`, Fountain, or UTF-8 text file. Headings such as `INT. KITCHEN - DAY` create scenes. Imports identify dialogue cues as candidate cast and estimate page eighths from extracted text; review both. PDF page labels come from extracted physical pages; FDX starts at page 1 because rendered pagination is not available.
2. In **Main breakdown**, read the script alongside its scene details. Select a scene in the script dropdown or click its strip. Edit the scene number, INT/EXT, day/night, set, shooting location, script day, unit, synopsis, page count, and estimated shooting minutes. Page counts use decimals in eighths: `0.125` = 1/8, `1.375` = 1 3/8.
3. Select text in the script and click **Tag selection**, or type elements into category cells. Elements are reused by name within a category. Remove a tag with its × button. Editing scene text does not automatically retag or update the breakdown fields.
4. Open **Shooting schedule** and add shooting days. Drag strips from **Unscheduled** into a day, between days, or onto another strip to insert above it. Use the **Move scene** dropdown on a sheet for the same operation without dragging. Removing a day returns its scenes to Unscheduled. Banners are created in Unscheduled and can be dragged into a day.
5. Set the start date, weekly days off, and individual days off in **Production settings**. Shooting days follow that calendar. In **Elements**, set cast or equipment days off; conflicts are flagged on shooting days.
6. Click **◐** on any scene strip or banner to choose a palette color or a custom hex color. **Automatic** restores the default color. Strip colors are saved with each scene and are shared across scenarios; full backups retain them, while core USS exports exclude these local color overrides.
7. Duplicate a scenario to try a different schedule. Scenarios share breakdowns and initially share the same production calendar, while strip order is independent.
8. Use **Reports** for a one-line schedule, scene breakdown report, or cast workday matrix. **Print / Save PDF** opens your browser's local print dialog. Cast workdays show first/last/work days; hold, drop, and pickup rules are not calculated.

Undo / redo: Cmd-Z / Cmd-Shift-Z (Ctrl on other platforms), when not typing. Save: Cmd-S / Ctrl-S. The header confirms disk saves; clicking a failed save retries. Keep one browser window open for editing a given workspace.

## Shot list and SP identity

**Shot list → New shot** creates a numbered shot linked to a scene. Add a description and setup/shoot estimates, then use the detail panel to enter shot size, movement, camera, lens, equipment, priority, notes, takes, and circle takes. Numbers are unique within a scene and can be edited. Duplicate copies a setup with a fresh number and resets production tracking. Drag shots to reorder or use the up/down buttons.

Filter by shooting day, scene, status, or search. Adding or duplicating a shot keeps those filters and your scroll position. A new shot uses the selected shot’s setup and shoot estimates; its scene defaults to the scene filter or selected shot. If it falls outside the current filters, a message explains why it is hidden. Estimated total and remaining time display minutes, hours, and days, with one day equal to 24 hours. Shots follow their scene's day in the selected schedule scenario. Select one day to see planned clock times from the production's shot start time. All days show cumulative offsets instead. Filters hide rows without recalculating their clock times. Complete or reopen a shot with its circle button; omitted shots are excluded from estimates. Enter actual total minutes manually, including setup; the variance compares only completed shots with actual times reported. Changing scene estimates does not overwrite shot estimates. Deleting a scene also deletes its shots; Undo restores both.

**Export shots** saves the filtered list as CSV. **Print / PDF** prints the filtered shot list with camera details and notes. Full workspace backups preserve all shots. Shots are a local extension (`_shots`, `_shotSettings`), so core USS interchange files exclude them; use a full backup to move all of your work between Production Desk installations.

The interface and app icon use the supplied SP logo, Spanish Red (`#E60026`), white panels, and dark text. Script displays and script editing use Courier Final Draft from the locally installed Final Draft app, including bold and italic variants. If Final Draft or its fonts are removed, script text falls back to Courier New. The font files are read locally and are not copied into the installer. Futura uses the installed system font. Headings use **Reross Quadratic** (also sold as Reross Std Quadratic) from this Mac's local Adobe font cache. It is loaded through localhost without contacting Adobe or copying the font into the installer. If that font is removed from the computer, headings fall back to Futura. This app does not activate Adobe fonts or require a cloud connection.

## Files and offline operation

All runtime assets are included in `web/`. Fonts come from this computer. There are no CDNs or analytics. The native updater checks the configured HTTPS update feed. Update checks do not send production files or enable Sparkle's system profiling. The server listens on `127.0.0.1` only, so it is not exposed to your Wi-Fi network. A Content Security Policy restricts the app to its own local origin. Origin and Host checks block cross-origin API writes. The browser communicates with a server on this computer; local work continues with Wi-Fi disconnected.

The workspace is saved to `data/workspace.json` using an atomic file replacement. `data/workspace.previous.json` retains the prior successful save. These contain full scene text, breakdowns, elements, schedules, and shot lists. If you need to recover, stop the server and preserve both files before replacing `workspace.json` with a copy of the previous version.

**Export → Full Production Desk backup** saves all productions, script text, and shots to a JSON file. Import that file to restore productions alongside the existing workspace. Duplicate production IDs are remapped to avoid collisions. Export backups regularly to protect against computer or disk failure.

**Export → Universal Schedule Standard** creates a `.uss` interchange file for the current production. It includes scenes, banners, category IDs, elements, all scenarios, and calendars. Full script text, shot lists, and Production Desk-only flags are excluded; use a Production Desk backup to retain them. CSV export includes the selected scenario's main shooting board.

## Universal Schedule Standard

Implemented against the published [USS 1.0.0 documentation](https://github.com/UniversalScheduleStandard/UniversalScheduleStandard/blob/main/docs/docs.md) and [Universal Category Identification](https://github.com/UniversalScheduleStandard/UniversalCategoryIdentification):

- `universalScheduleStandard` root with standard header keys.
- Scene and banner breakdowns; fractional pages stored as decimal eighths and shooting durations in milliseconds.
- Set, INT/EXT, day/night, script day, unit, and location represented as category-linked elements.
- Category `ucid` values follow the published category registry.
- Scenarios represented as stripboard objects, with ordered boards. Shooting days are nested arrays of breakdown IDs; the unscheduled board is `boneyard`.
- Calendars represent start dates and days off through events and weekday arrays.
- Script text and internal review flags use underscore-prefixed extensions in local backups.

Import validates relationships, duplicate IDs, required data structures, dates, and numeric values. USS export is built to the published structure; compatibility with each third-party scheduling application still needs testing with that application's importer. Unknown standard fields and underscore extensions in imported objects are retained in local storage. The app displays a primary board and additional holding boards for the selected scenario.

## Current limits

This is a functional first version for local breakdown and scheduling. PDF extraction needs a text layer: scanned or encrypted PDFs may not import. Layout, page lengths, scene numbering, and character cues should be reviewed, particularly for unusual PDF formatting. It does not yet support OCR, script revision reconciliation, Final Draft tag metadata, automatic optimization, call sheets, multi-user collaboration, or advanced DOOD hold/drop logic. Mac uses a native Swift/WebKit package and PDFKit. Windows uses Electron with the same web interface and backend, plus a bundled pypdf text extractor.

## Development and checks

Run `python3 -m unittest discover -s tests -v`. Start an isolated workspace with `python3 server.py --port 8766 --data /tmp/slate-test-workspace.json`.

Source layout: `film.py` for script parsing and USS data checks, `server.py` for local serving/persistence, `web/` for the browser UI, `tools/extract_pdf.swift` for PDFKit extraction. No build tool is needed for the UI.

Desktop source is in `desktop/Slate.swift`. Build the self-contained app and DMG offline with `python3 tools/build_macos.py` (requires the local Xcode/Swift build tools and Python3.framework used on this Mac). Use `--app-only` to omit the DMG. The app includes the Python framework and its `LICENSE.txt`, the PDF helper, and all web assets. Its server uses an automatically selected loopback port and exits if the app process disappears. The desktop webview keeps the workspace local.

The USS and category standards are maintained by their respective authors under CC BY-ND 4.0. Production Desk implements their data format; it does not redistribute modified specification documents. Think Crew and Shot Lister are separate products and are not affiliated with Production Desk. The shot-list workflow is inspired by [Shot Lister](https://www.shotlister.com/).

## Appearance

The gear **Settings** button above **Quick guide** switches between Light and Dark. Appearance is saved on this device independently of production backups. The sidebar reads “A Squid Productions™ Software.” Production settings still controls the production title, calendar, and days off.

To create just the current Mac application without duplicate installers: `python3 tools/build_macos.py --app-only --no-share`.

To package the installed version for sharing without rebuilding it: `python3 tools/build_macos.py --share-from "$HOME/Applications/Production Desk.app"`. This creates the share folder and ZIP in `dist/`. The ZIP includes the complete installer and a recipient guide, without production data.

On **Elements**, right-click a row or use its **⋯** button to choose **Delete element**. Confirming removes it from the current production, every breakdown, and linked-element references. Undo restores the element and its scene assignments. Shift+F10 opens the row menu from the keyboard.

Bug reports: email **alexanderhosier@squidproductions.org**. Include the Production Desk version, operating system version, reproduction steps, expected behavior, actual behavior, and any useful screenshots. The same contact details appear in **Quick guide**.

In **Production settings → Delete production…**, confirm to remove the current production and all of its script, breakdowns, schedules, and shots. Other productions remain available. Undo restores the entire deleted production; Redo deletes it again. Deleting the last production opens a new blank “Untitled production” so you can keep working. The download site uses the same `#191419` background as the app’s Dark appearance.

## Windows desktop

Download **Production-Desk-Windows-Setup.exe** from the public download page or [GitHub Releases](https://github.com/OfficialSquidProductions/production-desk-updates/releases/latest). This single file installs the full offline app on Windows 10/11 x64, including its desktop engine, Python and PDF reader. No separate runtime installation or administrator password is needed. Windows may show a SmartScreen prompt for this unsigned personal build.

Projects and settings live in **%APPDATA%/production-desk/** and survive reinstalls. Full workspace backups transfer all productions, scripts, shots and schedules between Mac and Windows. The Windows **Production Desk** menu includes update checks, optional automatic downloading/installation and **Open Data Folder**. Updates and quitting wait for pending saves.

See [Windows build and verification instructions](desktop/windows/README.md). The published Windows source is under `windows-src/` in the release repository; GitHub Actions builds, tests and publishes the one-file installer.

## Open source

Production Desk is free and open source under the [MIT license](LICENSE).
The public repository is [OfficialSquidProductions/production-desk-updates](https://github.com/OfficialSquidProductions/production-desk-updates).
Its `windows-src/` directory contains the shared desktop source and Mac/Windows
build tools; `ios/` contains the native iPhone/iPad edition.
See [CONTRIBUTING.md](CONTRIBUTING.md) and [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).
